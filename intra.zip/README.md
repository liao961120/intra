Theory-Driven Analysis of Intra-individual Dynamics
===================================================

- [Manuscript](https://yongfu.name/intra/main.pdf)
- [Analysis documentation](https://yongfu.name/intra)
- [Archive](https://yongfu.name/intra/intra.zip)

To build the documents above, run:

```bash
bash build.sh
```
