pandoc main.md -f markdown -t html5 --citeproc -s -o docs/main.html --katex --default-image-extension ".svg"
# mkdir docs/fig
# cp fig/*.svg docs/fig
